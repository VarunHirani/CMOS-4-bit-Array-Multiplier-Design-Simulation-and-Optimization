* SPICE export by:  S-Edit 2019.2.3
* Export time:      Tue Apr 21 22:30:48 2026
* Design path:      E:\6th Semester\EE635 Digital IC Design Nandekumar Sir\EE635Project\lib.defs
* Library:          EE635Project
* Cell:             TG_XOR_VTC
* Testbench:        Spice
* View:             schematic
* Export as:        top-level cell
* Export mode:      hierarchical
* Exclude empty:    yes
* Exclude .model:   no
* Exclude .hdl:     no
* Exclude .end:     no
* Expand paths:     yes
* Wrap lines:       no
* Exclude simulator commands:  no
* Exclude global pins:         no
* Exclude instance locations:  no
* Control property name(s):    SPICE

********* Simulation Settings - General Section *********
.lib "E:\6th Semester\EE635 Digital IC Design Nandekumar Sir\TannerTools_v2019.2\Process\Generic_250nm\Models\Generic_250nm.lib" TT

*************** Subcircuits *****************
.subckt TG_XOR A B Gnd Vdd Y 
MMn1 N_1 A Gnd Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=8600 $y=20900 $w=400 $h=600
MMn2 Y B N_1 Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=10000 $y=20900 $w=400 $h=600
MMn3 Y N_1 B Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=11700 $y=21000 $w=600 $h=400 $r=270
MMp1 N_1 A Vdd Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=8600 $y=22400 $w=400 $h=600
MMp2 Y B A Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=10000 $y=22400 $w=400 $h=600
MMp3 Y A B Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=11700 $y=22500 $w=600 $h=400 $r=90
.ends


***** Top Level *****
XTG_XOR_1 A B Gnd Vdd Y TG_XOR $ $x=13100 $y=17600 $w=1800 $h=1800

********* Simulation Settings - Analysis Section *********
********* Simulation Settings - Analysis Section *********
* EE 635: 6T TG-XOR Gate Characterization & Delay Measurement

* --- 1. Technology & Power ---
Vdd Vdd 0 DC 2.5
Vgnd Gnd 0 DC 0 

* --- 2. Input Stimulus ---
* Keep A constant at Logic 0 (0 Volts)
Va A 0 DC 0

* Pulse B from 0 to 1 (0V to 2.5V)
* Format: PULSE(V1 V2 Tdelay Trise Tfall Ton Tperiod)
Vb B 0 PULSE(0 2.5 2n 100p 100p 4n 10n)

* --- 3. Analysis ---
.tran 10p 10n

* --- 4. Probing ---
.print tran v(A) v(B) v(Y)

* --- 5. Propagation Delay Measurements ---
* 50% of Vdd (2.5V) is 1.25V

* Measure Low-to-High Delay (t_pLH)
* Measures the time from B rising past 1.25V to Y rising past 1.25V
.measure tran tplh TRIG v(B) VAL=1.25 RISE=1 TARG v(Y) VAL=1.25 RISE=1

* Measure High-to-Low Delay (t_pHL)
* Measures the time from B falling past 1.25V to Y falling past 1.25V
.measure tran tphl TRIG v(B) VAL=1.25 FALL=1 TARG v(Y) VAL=1.25 FALL=1

* Calculate Average Propagation Delay (t_pd)
.measure tran tpd param='(tplh+tphl)/2'

* --- 6. Solver Options (Optimized for Speed) ---
.option gmin=1e-12
.option abstol=1e-9
.option reltol=0.01
.option threads=8
.option dcmethod=multiparameter

********* Simulation Settings - Additional SPICE Commands *********
.end
********* Simulation Settings - Additional SPICE Commands *********

.end


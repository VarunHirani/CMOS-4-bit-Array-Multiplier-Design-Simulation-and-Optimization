* SPICE export by:  S-Edit 2019.2.3
* Export time:      Thu Apr 23 11:25:07 2026
* Design path:      E:\6th Semester\EE635 Digital IC Design Nandekumar Sir\EE635Project\lib.defs
* Library:          EE635Project
* Cell:             optimised_multiplier_vtc
* Testbench:        Spice
* View:             schematic4
* Export as:        top-level cell
* Export mode:      hierarchical
* Exclude empty:    yes
* Exclude .model:   no
* Exclude .hdl:     no
* Exclude .end:     no
* Expand paths:     yes
* Wrap lines:       no
* Exclude simulator commands:  no
* Exclude global pins:         no
* Exclude instance locations:  no
* Control property name(s):    SPICE

********* Simulation Settings - General Section *********
.lib "E:\6th Semester\EE635 Digital IC Design Nandekumar Sir\TannerTools_v2019.2\Process\Generic_250nm\Models\Generic_250nm.lib" TT

*************** Subcircuits *****************
.subckt INVERTER Gnd Vdd Vin Vout 
MMn1 Vout Vin Gnd Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=4700 $y=4800 $w=400 $h=600
MMp1 Vout Vin Vdd Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=4700 $y=5600 $w=400 $h=600
.ends

.subckt NAND A B Gnd NAND_OUT Vdd 
MMn1 NAND_OUT A N_1 Gnd NMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=4600 $y=3700 $w=400 $h=600
MMn2 N_1 B Gnd Gnd NMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=4600 $y=2700 $w=400 $h=600
MMp1 NAND_OUT A Vdd Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=3700 $y=4900 $w=400 $h=600
MMp2 NAND_OUT B Vdd Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=5600 $y=4900 $w=400 $h=600
.ends

.subckt AND2 A AND_OUT B Gnd Vdd 
XINVERTER_1 Gnd Vdd N_1 AND_OUT INVERTER $ $x=6700 $y=3900 $w=1800 $h=1800
XNAND_1 A B Gnd N_1 Vdd NAND $ $x=3900 $y=3900 $w=1800 $h=1800
.ends

.subckt TG_XOR A B Gnd Vdd Y 
MMn1 N_1 A Gnd Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=8600 $y=20900 $w=400 $h=600
MMn2 Y B N_1 Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=10000 $y=20900 $w=400 $h=600
MMn3 Y N_1 B Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=11700 $y=21000 $w=600 $h=400 $r=270
MMp1 N_1 A Vdd Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=8600 $y=22400 $w=400 $h=600
MMp2 Y B A Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=10000 $y=22400 $w=400 $h=600
MMp3 Y A B Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=11700 $y=22500 $w=600 $h=400 $r=90
.ends

.subckt HALF_ADDER_OPT A B COUT Gnd SUM Vdd 
XAND2_1 A COUT B Gnd Vdd AND2 $ $x=13900 $y=22100 $w=1800 $h=1800
XTG_XOR_1 A B Gnd Vdd SUM TG_XOR $ $x=11800 $y=22100 $w=1800 $h=1800
XTG_XOR_2 A B Gnd Vdd SUM TG_XOR $ $x=11800 $y=22100 $w=1800 $h=1800
.ends

.subckt serf_adder_copy A B Cin COUT Gnd SUM Vdd 
XINVERTER_1 Gnd Vdd N_3 SUM INVERTER $ $x=14900 $y=17400 $w=1800 $h=1800
XINVERTER_3 Gnd Vdd N_4 N_5 INVERTER $ $x=15100 $y=15100 $w=1800 $h=1800
XINVERTER_4 Gnd Vdd N_5 COUT INVERTER $ $x=16900 $y=15100 $w=1800 $h=1800
XTG_XOR_1 A B Gnd Vdd N_2 TG_XOR $ $x=9900 $y=17300 $w=1800 $h=1800
MMn1 N_3 N_2 Cin Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=12800 $y=17200 $w=400 $h=600
MMn2 N_3 Cin N_2 Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=13800 $y=17200 $w=400 $h=600
MMn5 Cin N_2 N_4 Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=13200 $y=15800 $w=600 $h=400 $r=270
MMp1 N_1 Cin Vdd Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=13300 $y=18700 $w=400 $h=600
MMp2 N_3 N_2 N_1 Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=13300 $y=18000 $w=400 $h=600
MMp5 A N_2 N_4 Vdd PMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=13200 $y=15000 $w=600 $h=400 $r=90
.ends

.subckt OPTIMISED_RIPPLE_ADDER A0 A1 A2 A3 B0 B1 B2 B3 Gnd S0 S1 S2 S3 S4 Vdd 
XHALF_ADDER_OPT_1 A0 B0 N_1 Gnd S0 Vdd HALF_ADDER_OPT $ $x=6200 $y=19600 $w=1800 $h=1800
Xserf_adder_copy_1 A1 B1 N_1 N_2 Gnd S1 Vdd serf_adder_copy $ $x=8500 $y=19700 $w=1800 $h=2000
Xserf_adder_copy_2 A2 B2 N_2 N_3 Gnd S2 Vdd serf_adder_copy $ $x=10800 $y=19900 $w=1800 $h=2000
Xserf_adder_copy_3 A3 B3 N_3 S4 Gnd S3 Vdd serf_adder_copy $ $x=13400 $y=20100 $w=1800 $h=2000
.ends

.subckt optimised_multiplier A0 A1 A2 A3 B0 B1 B2 B3 Gnd P0 P1 P2 P3 P4 P5 P6 P7 Vdd 
XAND2_1 B0 N_11 A3 Gnd Vdd AND2 $ $x=16300 $y=20400 $w=1800 $h=1800 $r=90
XAND2_2 B0 N_5 A2 Gnd Vdd AND2 $ $x=18500 $y=20400 $w=1800 $h=1800 $r=90
XAND2_3 B0 N_1 A1 Gnd Vdd AND2 $ $x=20700 $y=20400 $w=1800 $h=1800 $r=90
XAND2_4 B0 P0 A0 Gnd Vdd AND2 $ $x=22900 $y=20400 $w=1800 $h=1800 $r=90
XAND2_5 B1 N_17 A3 Gnd Vdd AND2 $ $x=6200 $y=20100 $w=1800 $h=1800 $r=90
XAND2_6 B1 N_12 A2 Gnd Vdd AND2 $ $x=8400 $y=20100 $w=1800 $h=1800 $r=90
XAND2_7 B1 N_6 A1 Gnd Vdd AND2 $ $x=10600 $y=20100 $w=1800 $h=1800 $r=90
XAND2_8 B1 N_2 A0 Gnd Vdd AND2 $ $x=12800 $y=20100 $w=1800 $h=1800 $r=90
XAND2_9 B2 N_18 A3 Gnd Vdd AND2 $ $x=6300 $y=17000 $w=1800 $h=1800 $r=90
XAND2_10 B2 N_13 A2 Gnd Vdd AND2 $ $x=8500 $y=17000 $w=1800 $h=1800 $r=90
XAND2_11 B2 N_7 A1 Gnd Vdd AND2 $ $x=10700 $y=17000 $w=1800 $h=1800 $r=90
XAND2_12 B2 N_3 A0 Gnd Vdd AND2 $ $x=12900 $y=17000 $w=1800 $h=1800 $r=90
XAND2_13 B3 N_19 A3 Gnd Vdd AND2 $ $x=6500 $y=13400 $w=1800 $h=1800 $r=90
XAND2_14 B3 N_14 A2 Gnd Vdd AND2 $ $x=8700 $y=13400 $w=1800 $h=1800 $r=90
XAND2_15 B3 N_8 A1 Gnd Vdd AND2 $ $x=10900 $y=13400 $w=1800 $h=1800 $r=90
XAND2_16 B3 N_4 A0 Gnd Vdd AND2 $ $x=13100 $y=13400 $w=1800 $h=1800 $r=90
XOPTIMISED_RIPPLE_ADDER_1 N_1 N_5 N_11 Gnd N_2 N_6 N_12 N_17 Gnd P1 N_9 N_15 N_20 N_22 Vdd OPTIMISED_RIPPLE_ADDER $ $x=20100 $y=18000 $w=3000 $h=1800 $r=90
XOPTIMISED_RIPPLE_ADDER_2 N_9 N_15 N_20 N_22 N_3 N_7 N_13 N_18 Gnd P2 N_10 N_16 N_21 N_23 Vdd OPTIMISED_RIPPLE_ADDER $ $x=19900 $y=14300 $w=3000 $h=1800 $r=90
XOPTIMISED_RIPPLE_ADDER_3 N_10 N_16 N_21 N_23 N_4 N_8 N_14 N_19 Gnd P3 P4 P5 P6 P7 Vdd OPTIMISED_RIPPLE_ADDER $ $x=19700 $y=11200 $w=3000 $h=1800 $r=90
.ends


***** Top Level *****
Xoptimised_multiplier_1 A0 A1 A2 A3 B0 B1 B2 B3 Gnd P0 P1 P2 P3 P4 P5 P6 P7 Vdd optimised_multiplier $ $x=14100 $y=18200 $w=1800 $h=3000

********* Simulation Settings - Analysis Section *********
********* Simulation Settings - Analysis Section *********
* EE 635: 4x4 Array Multiplier - Functional Logic Verification

* --- 1. Technology & Power ---
Vdd Vdd 0 DC 2.5
Vgnd Gnd 0 DC 0 

* --- 2. Input Stimulus (Piecewise Linear Sequence) ---
* A Sequence: 3 (0011) -> 10 (1010) -> 15 (1111)
Va3 A3 0 PWL(0 0    9.9n 0    10n 2.5  30n 2.5)
Va2 A2 0 PWL(0 0    19.9n 0   20n 2.5  30n 2.5)
Va1 A1 0 DC 2.5
Va0 A0 0 PWL(0 2.5  9.9n 2.5  10n 0    19.9n 0   20n 2.5  30n 2.5)

* B Sequence: 5 (0101) -> 6 (0110) -> 15 (1111)
Vb3 B3 0 PWL(0 0    19.9n 0   20n 2.5  30n 2.5)
Vb2 B2 0 DC 2.5
Vb1 B1 0 PWL(0 0    9.9n 0    10n 2.5  30n 2.5)
Vb0 B0 0 PWL(0 2.5  9.9n 2.5  10n 0    19.9n 0   20n 2.5  30n 2.5)

* --- 3. Analysis ---
* Run for 30ns to capture all three math problems
.tran 10p 30n

* --- 4. Probing ---
* Plotting the product bits to visually verify the math
.print tran v(P7)

* --- 5. Solver Options ---
.option gmin=1e-12
.option abstol=1e-9
.option reltol=0.01
.option threads=8
.option dcmethod=multiparameter

********* Simulation Settings - Additional SPICE Commands *********
.end
********* Simulation Settings - Additional SPICE Commands *********

.end


* SPICE export by:  S-Edit 2019.2.3
* Export time:      Thu Apr 23 15:42:02 2026
* Design path:      E:\6th Semester\EE635 Digital IC Design Nandekumar Sir\EE635Project\lib.defs
* Library:          EE635Project
* Cell:             serf_adder_copy
* Testbench:        Spice
* View:             schematic
* Export as:        top-level cell
* Export mode:      hierarchical
* Exclude empty:    yes
* Exclude .model:   no
* Exclude .hdl:     no
* Exclude .end:     no
* Expand paths:     yes
* Wrap lines:       no
* Exclude simulator commands:  no
* Exclude global pins:         no
* Exclude instance locations:  no
* Control property name(s):    SPICE

********* Simulation Settings - General Section *********

*************** Subcircuits *****************
.subckt INVERTER Gnd Vdd Vin Vout 
MMn1 Vout Vin Gnd Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=4700 $y=4800 $w=400 $h=600
MMp1 Vout Vin Vdd Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=4700 $y=5600 $w=400 $h=600
.ends

.subckt TG_XOR A B Gnd Vdd Y 
MMn1 N_1 A Gnd Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=8600 $y=20900 $w=400 $h=600
MMn2 Y B N_1 Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=10000 $y=20900 $w=400 $h=600
MMn3 Y N_1 B Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=11700 $y=21000 $w=600 $h=400 $r=270
MMp1 N_1 A Vdd Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=8600 $y=22400 $w=400 $h=600
MMp2 Y B A Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=10000 $y=22400 $w=400 $h=600
MMp3 Y A B Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=11700 $y=22500 $w=600 $h=400 $r=90
.ends


***** Top Level *****
XINVERTER_1 Gnd Vdd N_3 SUM INVERTER $ $x=14900 $y=17400 $w=1800 $h=1800
XINVERTER_3 Gnd Vdd N_4 N_5 INVERTER $ $x=15100 $y=15100 $w=1800 $h=1800
XINVERTER_4 Gnd Vdd N_5 COUT INVERTER $ $x=16900 $y=15100 $w=1800 $h=1800
XTG_XOR_1 A B Gnd Vdd N_2 TG_XOR $ $x=9900 $y=17300 $w=1800 $h=1800
MMn1 N_3 N_2 Cin Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=12800 $y=17200 $w=400 $h=600
MMn2 N_3 Cin N_2 Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=13800 $y=17200 $w=400 $h=600
MMn5 Cin N_2 N_4 Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=13200 $y=15800 $w=600 $h=400 $r=270
MMp1 N_1 Cin Vdd Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=13300 $y=18700 $w=400 $h=600
MMp2 N_3 N_2 N_1 Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=13300 $y=18000 $w=400 $h=600
MMp5 A N_2 N_4 Vdd PMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=13200 $y=15000 $w=600 $h=400 $r=90

********* Simulation Settings - Analysis Section *********
********* Simulation Settings - Analysis Section *********
* EE 635: 18T Hybrid Full Adder Complete Propagation Delay Test

* --- 1. Technology & Power ---
Vdd Vdd 0 DC 2.5
Vgnd Gnd 0 DC 0 

* --- 2. Input Stimulus ---
* Hold A at 1, B at 0
Va A 0 DC 2.5
Vb B 0 DC 0

* Pulse Cin to trigger all transitions (0 -> 1 -> 0)
Vcin Cin 0 PULSE(0 2.5 2n 100p 100p 4n 10n)

* --- 3. Analysis ---
.tran 10p 10n

* --- 4. Probing ---
.print tran v(Cin) v(SUM) v(COUT)

* --- 5. Propagation Delay Measurements (50% Vdd = 1.25V) ---

* SUM Measurements
* tphl: Cin rises (0->1), SUM falls (1->0)
.measure tran tphl_sum TRIG v(Cin) VAL=1.25 RISE=1 TARG v(SUM) VAL=1.25 FALL=1
* tplh: Cin falls (1->0), SUM rises (0->1)
.measure tran tplh_sum TRIG v(Cin) VAL=1.25 FALL=1 TARG v(SUM) VAL=1.25 RISE=1
* Final Average Delay for SUM
.measure tran tpd_sum param='(tplh_sum+tphl_sum)/2'

* COUT Measurements
* tplh: Cin rises (0->1), COUT rises (0->1)
.measure tran tplh_cout TRIG v(Cin) VAL=1.25 RISE=1 TARG v(COUT) VAL=1.25 RISE=1
* tphl: Cin falls (1->0), COUT falls (1->0)
.measure tran tphl_cout TRIG v(Cin) VAL=1.25 FALL=1 TARG v(COUT) VAL=1.25 FALL=1
* Final Average Delay for COUT
.measure tran tpd_cout param='(tplh_cout+tphl_cout)/2'

* --- 6. Solver Options ---
.option gmin=1e-12
.option abstol=1e-9
.option reltol=0.01
.option threads=8
.option dcmethod=multiparameter

********* Simulation Settings - Additional SPICE Commands *********
.end
********* Simulation Settings - Additional SPICE Commands *********

.end


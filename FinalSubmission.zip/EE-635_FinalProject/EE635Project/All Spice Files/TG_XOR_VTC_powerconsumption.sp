* SPICE export by:  S-Edit 2019.2.3
* Export time:      Thu Apr 23 19:24:37 2026
* Design path:      E:\6th Semester\EE635 Digital IC Design Nandekumar Sir\EE635Project\lib.defs
* Library:          EE635Project
* Cell:             TG_XOR_VTC
* Testbench:        Spice
* View:             schematic
* Export as:        top-level cell
* Export mode:      hierarchical
* Exclude empty:    yes
* Exclude .model:   no
* Exclude .hdl:     no
* Exclude .end:     no
* Expand paths:     yes
* Wrap lines:       no
* Exclude simulator commands:  no
* Exclude global pins:         no
* Exclude instance locations:  no
* Control property name(s):    SPICE

********* Simulation Settings - General Section *********
.lib "E:\6th Semester\EE635 Digital IC Design Nandekumar Sir\TannerTools_v2019.2\Process\Generic_250nm\Models\Generic_250nm.lib" TT

*************** Subcircuits *****************
.subckt TG_XOR A B Gnd Vdd Y 
MMn1 N_1 A Gnd Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=8600 $y=20900 $w=400 $h=600
MMn2 Y B N_1 Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=10000 $y=20900 $w=400 $h=600
MMn3 Y N_1 B Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=11700 $y=21000 $w=600 $h=400 $r=270
MMp1 N_1 A Vdd Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=8600 $y=22400 $w=400 $h=600
MMp2 Y B A Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=10000 $y=22400 $w=400 $h=600
MMp3 Y A B Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=11700 $y=22500 $w=600 $h=400 $r=90
.ends


***** Top Level *****
XTG_XOR_1 A B Gnd Vdd Y TG_XOR $ $x=13100 $y=17600 $w=1800 $h=1800

********* Simulation Settings - Analysis Section *********
********* Simulation Settings - XOR Power Analysis *********
* EE 635: 6T TG-XOR Power Consumption Test

* --- 1. Technology & Power ---

Vdd Vdd 0 DC 2.5
Vgnd Gnd 0 DC 0 

* --- 2. Input Stimulus (Binary Counter Pattern) ---
* 2ns delay to measure static leakage, then cycle all 4 states
Va A 0 PULSE(0 2.5 2n 100p 100p 2n 4n)
Vb B 0 PULSE(0 2.5 2n 100p 100p 4n 8n)

* --- 3. Analysis ---
.tran 10p 12n

* --- 4. Probing ---
.print tran v(A) v(B) v(Y)
.print tran I(Vdd)

* --- 5. Power Measurements ---
* Total Average Power (across all 4 state transitions)
.measure tran I_avg_xor AVG I(Vdd) FROM=0n TO=12n
.measure tran P_avg_xor param='abs(I_avg_xor) * 2.5'

* Static/Leakage Power (Measured during the quiet 00 state)
.measure tran I_stat_xor AVG I(Vdd) FROM=0.1n TO=1.9n
.measure tran P_stat_xor param='abs(I_stat_xor) * 2.5'

* Peak Switching Power (Measuring the 00 -> 11 simultaneous toggle)
.measure tran I_stress_xor AVG I(Vdd) FROM=9.9n TO=10.5n
.measure tran P_stress_xor param='abs(I_stress_xor) * 2.5'

.option gmin=1e-12 abstol=1e-9 reltol=0.01 threads=8
.end
********* Simulation Settings - Additional SPICE Commands *********

.end


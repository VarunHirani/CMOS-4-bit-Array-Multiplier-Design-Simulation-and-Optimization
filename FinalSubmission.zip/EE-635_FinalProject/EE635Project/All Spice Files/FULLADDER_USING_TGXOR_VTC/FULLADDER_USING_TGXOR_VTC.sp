* SPICE export by:  S-Edit 2019.2.3
* Export time:      Tue Apr 21 23:09:54 2026
* Design path:      E:\6th Semester\EE635 Digital IC Design Nandekumar Sir\EE635Project\lib.defs
* Library:          EE635Project
* Cell:             FULLADDER_USING_TGXOR_VTC
* Testbench:        Spice
* View:             schematic
* Export as:        top-level cell
* Export mode:      hierarchical
* Exclude empty:    yes
* Exclude .model:   no
* Exclude .hdl:     no
* Exclude .end:     no
* Expand paths:     yes
* Wrap lines:       no
* Exclude simulator commands:  no
* Exclude global pins:         no
* Exclude instance locations:  no
* Control property name(s):    SPICE

********* Simulation Settings - General Section *********
.lib "E:\6th Semester\EE635 Digital IC Design Nandekumar Sir\TannerTools_v2019.2\Process\Generic_250nm\Models\Generic_250nm.lib" TT

*************** Subcircuits *****************
.subckt TG_XOR A B Gnd Vdd Y 
MMn1 N_1 A Gnd Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=8600 $y=20900 $w=400 $h=600
MMn2 Y B N_1 Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=10000 $y=20900 $w=400 $h=600
MMn3 Y N_1 B Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=11700 $y=21000 $w=600 $h=400 $r=270
MMp1 N_1 A Vdd Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=8600 $y=22400 $w=400 $h=600
MMp2 Y B A Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=10000 $y=22400 $w=400 $h=600
MMp3 Y A B Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=11700 $y=22500 $w=600 $h=400 $r=90
.ends

.subckt INVERTER Gnd Vdd Vin Vout 
MMn1 Vout Vin Gnd Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=4700 $y=4800 $w=400 $h=600
MMp1 Vout Vin Vdd Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=4700 $y=5600 $w=400 $h=600
.ends

.subckt NAND A B Gnd NAND_OUT Vdd 
MMn1 NAND_OUT A N_1 Gnd NMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=4600 $y=3700 $w=400 $h=600
MMn2 N_1 B Gnd Gnd NMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=4600 $y=2700 $w=400 $h=600
MMp1 NAND_OUT A Vdd Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=3700 $y=4900 $w=400 $h=600
MMp2 NAND_OUT B Vdd Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=5600 $y=4900 $w=400 $h=600
.ends

.subckt AND2 A AND_OUT B Gnd Vdd 
XINVERTER_1 Gnd Vdd N_1 AND_OUT INVERTER $ $x=6700 $y=3900 $w=1800 $h=1800
XNAND_1 A B Gnd N_1 Vdd NAND $ $x=3900 $y=3900 $w=1800 $h=1800
.ends

.subckt NOR2 A B Gnd NOR_OUT Vdd 
MMn1 NOR_OUT A Gnd Gnd NMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=4000 $y=4200 $w=400 $h=600
MMn2 NOR_OUT B Gnd Gnd NMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=5500 $y=4200 $w=400 $h=600
MMp1 N_1 A Vdd Vdd PMOS25 w=6u l=250n m=1 ad=3.9p pd=13.3u as=3.9p ps=13.3u nrd=108.33333m nrs=108.33333m $ $x=4700 $y=6100 $w=400 $h=600
MMp2 NOR_OUT B N_1 Vdd PMOS25 w=6u l=250n m=1 ad=3.9p pd=13.3u as=3.9p ps=13.3u nrd=108.33333m nrs=108.33333m $ $x=4700 $y=5200 $w=400 $h=600
.ends

.subckt OR_2 A B Gnd OR_OUT Vdd 
XINVERTER_1 Gnd Vdd N_1 OR_OUT INVERTER $ $x=6000 $y=4200 $w=1800 $h=1800
XNOR2_1 A B Gnd N_1 Vdd NOR2 $ $x=3500 $y=4200 $w=1800 $h=1800
.ends

.subckt FULLADDER_USING_TGXOR A B Cin COUT Gnd SUM Vdd 
XAND2_1 A N_1 B Gnd Vdd AND2 $ $x=7900 $y=22700 $w=1800 $h=1800
XAND2_2 N_6 N_2 Cin Gnd Vdd AND2 $ $x=10300 $y=22700 $w=1800 $h=1800
XINVERTER_1 Gnd Vdd N_3 N_5 INVERTER $ $x=6100 $y=25300 $w=1800 $h=1800
XINVERTER_2 Gnd Vdd N_5 N_6 INVERTER $ $x=7900 $y=25300 $w=1800 $h=1800
XINVERTER_3 Gnd Vdd N_4 N_7 INVERTER $ $x=12600 $y=25300 $w=1800 $h=1800
XINVERTER_4 Gnd Vdd N_7 SUM INVERTER $ $x=14400 $y=25300 $w=1800 $h=1800
XOR_2_1 N_2 N_1 Gnd COUT Vdd OR_2 $ $x=12400 $y=22700 $w=1800 $h=1800
XTG_XOR_1 A B Gnd Vdd N_3 TG_XOR $ $x=4300 $y=25300 $w=1800 $h=1800
XTG_XOR_2 N_6 Cin Gnd Vdd N_4 TG_XOR $ $x=10800 $y=25300 $w=1800 $h=1800
.ends


***** Top Level *****
XFULLADDER_USING_TGXOR_1 A B Cin COUT Gnd SUM Vdd FULLADDER_USING_TGXOR $ $x=12500 $y=18100 $w=1800 $h=2000

********* Simulation Settings - Analysis Section *********
* EE 635: Full Adder Exhaustive Truth Table Test

* --- 1. Technology & Power ---
Vdd Vdd 0 DC 2.5
Vgnd Gnd 0 DC 0 

* --- 2. Input Stimulus (3-Bit Binary Counter) ---
* Format: PULSE(V1 V2 Tdelay Trise Tfall Ton Tperiod)

* Cin (LSB) - Toggles every 2ns
Vcin Cin 0 PULSE(0 2.5 2n 100p 100p 2n 4n)

* B (Middle Bit) - Toggles every 4ns
Vb B 0 PULSE(0 2.5 4n 100p 100p 4n 8n)

* A (MSB) - Toggles every 8ns
Va A 0 PULSE(0 2.5 8n 100p 100p 8n 16n)

* --- 3. Analysis ---
* Run for 18ns to capture all 8 states (000 through 111) plus a little extra
.tran 50p 18n

* --- 4. Probing ---
* Plot inputs together, and outputs together to easily read the logic
.print tran v(A) v(B) v(Cin)
.print tran v(SUM) v(COUT)

* --- 5. Solver Options ---
.option gmin=1e-12
.option abstol=1e-9
.option reltol=0.01
.option threads=8
.option dcmethod=multiparameter

********* Simulation Settings - Additional SPICE Commands *********
.end
********* Simulation Settings - Additional SPICE Commands *********

.end


* SPICE export by:  S-Edit 2019.2.3
* Export time:      Thu Apr 23 10:22:56 2026
* Design path:      E:\6th Semester\EE635 Digital IC Design Nandekumar Sir\EE635Project\lib.defs
* Library:          EE635Project
* Cell:             TG_XOR_VTC
* Testbench:        Spice
* View:             schematic
* Export as:        top-level cell
* Export mode:      hierarchical
* Exclude empty:    yes
* Exclude .model:   no
* Exclude .hdl:     no
* Exclude .end:     no
* Expand paths:     yes
* Wrap lines:       no
* Exclude simulator commands:  no
* Exclude global pins:         no
* Exclude instance locations:  no
* Control property name(s):    SPICE

********* Simulation Settings - General Section *********
.lib "E:\6th Semester\EE635 Digital IC Design Nandekumar Sir\TannerTools_v2019.2\Process\Generic_250nm\Models\Generic_250nm.lib" TT

*************** Subcircuits *****************
.subckt TG_XOR A B Gnd Vdd Y 
MMn1 N_1 A Gnd Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=8600 $y=20900 $w=400 $h=600
MMn2 Y B N_1 Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=10000 $y=20900 $w=400 $h=600
MMn3 Y N_1 B Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=11700 $y=21000 $w=600 $h=400 $r=270
MMp1 N_1 A Vdd Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=8600 $y=22400 $w=400 $h=600
MMp2 Y B A Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=10000 $y=22400 $w=400 $h=600
MMp3 Y A B Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=11700 $y=22500 $w=600 $h=400 $r=90
.ends


***** Top Level *****
XTG_XOR_1 A B Gnd Vdd Y TG_XOR $ $x=13100 $y=17600 $w=1800 $h=1800

********* Simulation Settings - Analysis Section *********
********* Simulation Settings - Analysis Section *********
* EE 635: 6T TG-XOR Propagation Delay Test

Vdd Vdd 0 DC 2.5
Vgnd Gnd 0 DC 0 

Vb B 0 DC 0
Va A 0 PULSE(0 2.5 2n 100p 100p 4n 10n)

.tran 10p 10n
.print tran v(A) v(Y)

* Measure A (0->1) to Y (0->1)
.measure tran tplh_xor TRIG v(A) VAL=1.25 RISE=1 TARG v(Y) VAL=1.25 RISE=1
* Measure A (1->0) to Y (1->0)
.measure tran tphl_xor TRIG v(A) VAL=1.25 FALL=1 TARG v(Y) VAL=1.25 FALL=1
* Average Propagation Delay
.measure tran tpd_xor param='(tplh_xor+tphl_xor)/2'

.option gmin=1e-12 abstol=1e-9 reltol=0.01 threads=8
.end
********* Simulation Settings - Additional SPICE Commands *********

.end


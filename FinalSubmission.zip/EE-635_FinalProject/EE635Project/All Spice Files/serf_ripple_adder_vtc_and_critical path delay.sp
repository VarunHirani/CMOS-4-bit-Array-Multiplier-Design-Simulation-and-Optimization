* SPICE export by:  S-Edit 2019.2.3
* Export time:      Thu Apr 23 10:36:13 2026
* Design path:      E:\6th Semester\EE635 Digital IC Design Nandekumar Sir\EE635Project\lib.defs
* Library:          EE635Project
* Cell:             serf_ripple_adder_vtc
* Testbench:        Spice
* View:             schematic1
* Export as:        top-level cell
* Export mode:      hierarchical
* Exclude empty:    yes
* Exclude .model:   no
* Exclude .hdl:     no
* Exclude .end:     no
* Expand paths:     yes
* Wrap lines:       no
* Exclude simulator commands:  no
* Exclude global pins:         no
* Exclude instance locations:  no
* Control property name(s):    SPICE

********* Simulation Settings - General Section *********
.lib "E:\6th Semester\EE635 Digital IC Design Nandekumar Sir\TannerTools_v2019.2\Process\Generic_250nm\Models\Generic_250nm.lib" TT

*************** Subcircuits *****************
.subckt INVERTER Gnd Vdd Vin Vout 
MMn1 Vout Vin Gnd Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=4700 $y=4800 $w=400 $h=600
MMp1 Vout Vin Vdd Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=4700 $y=5600 $w=400 $h=600
.ends

.subckt TG_XOR A B Gnd Vdd Y 
MMn1 N_1 A Gnd Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=8600 $y=20900 $w=400 $h=600
MMn2 Y B N_1 Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=10000 $y=20900 $w=400 $h=600
MMn3 Y N_1 B Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=11700 $y=21000 $w=600 $h=400 $r=270
MMp1 N_1 A Vdd Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=8600 $y=22400 $w=400 $h=600
MMp2 Y B A Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=10000 $y=22400 $w=400 $h=600
MMp3 Y A B Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=11700 $y=22500 $w=600 $h=400 $r=90
.ends

.subckt serf_adder_copy A B Cin COUT Gnd SUM Vdd 
XINVERTER_1 Gnd Vdd N_3 SUM INVERTER $ $x=14900 $y=17400 $w=1800 $h=1800
XINVERTER_3 Gnd Vdd N_4 N_5 INVERTER $ $x=15100 $y=15100 $w=1800 $h=1800
XINVERTER_4 Gnd Vdd N_5 COUT INVERTER $ $x=16900 $y=15100 $w=1800 $h=1800
XTG_XOR_1 A B Gnd Vdd N_2 TG_XOR $ $x=9900 $y=17300 $w=1800 $h=1800
MMn1 N_3 N_2 Cin Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=12800 $y=17200 $w=400 $h=600
MMn2 N_3 Cin N_2 Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=13800 $y=17200 $w=400 $h=600
MMn5 Cin N_2 N_4 Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=13200 $y=15800 $w=600 $h=400 $r=270
MMp1 N_1 Cin Vdd Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=13300 $y=18700 $w=400 $h=600
MMp2 N_3 N_2 N_1 Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=13300 $y=18000 $w=400 $h=600
MMp5 A N_2 N_4 Vdd PMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=13200 $y=15000 $w=600 $h=400 $r=90
.ends

.subckt serf_ripple_adder A0 A1 A2 A3 B0 B1 B2 B3 Gnd S0 S1 S2 S3 S4 Vdd 
Xserf_adder_copy_1 A0 B0 Gnd N_1 Gnd S0 Vdd serf_adder_copy $ $x=5400 $y=22000 $w=1800 $h=2000
Xserf_adder_copy_2 A1 B1 N_1 N_2 Gnd S1 Vdd serf_adder_copy $ $x=8100 $y=22000 $w=1800 $h=2000
Xserf_adder_copy_3 A2 B2 N_2 N_3 Gnd S2 Vdd serf_adder_copy $ $x=10800 $y=22000 $w=1800 $h=2000
Xserf_adder_copy_4 A3 B3 N_3 S4 Gnd S3 Vdd serf_adder_copy $ $x=13600 $y=22000 $w=1800 $h=2000
.ends


***** Top Level *****
Xserf_ripple_adder_1 A0 A1 A2 A3 B0 B1 B2 B3 Gnd S0 S1 S2 S3 S4 Vdd serf_ripple_adder $ $x=12900 $y=17800 $w=1800 $h=3000

********* Simulation Settings - Analysis Section *********
********* Simulation Settings - Analysis Section *********
* EE 635: 4-Bit Ripple Carry Adder Critical Path

Vdd Vdd 0 DC 2.5
Vgnd Gnd 0 DC 0 

Va0 A0 0 DC 2.5
Va1 A1 0 DC 2.5
Va2 A2 0 DC 2.5
Va3 A3 0 DC 2.5

Vb1 B1 0 DC 0
Vb2 B2 0 DC 0
Vb3 B3 0 DC 0


Vb0 B0 0 PULSE(0 2.5 2n 100p 100p 4n 10n)

.tran 10p 10n
.print tran v(B0) v(S4)

* Critical Path Delay (B0 to final Carry Out S4)
.measure tran tplh_ripple TRIG v(B0) VAL=1.25 RISE=1 TARG v(S4) VAL=1.25 RISE=1
.measure tran tphl_ripple TRIG v(B0) VAL=1.25 FALL=1 TARG v(S4) VAL=1.25 FALL=1
.measure tran tpd_4bit_critical param='(tplh_ripple+tphl_ripple)/2'

.option gmin=1e-12 abstol=1e-9 reltol=0.01 threads=8
.end
********* Simulation Settings - Additional SPICE Commands *********

.end


* SPICE export by:  S-Edit 2019.2.3
* Export time:      Thu Apr 23 19:30:51 2026
* Design path:      E:\6th Semester\EE635 Digital IC Design Nandekumar Sir\EE635Project\lib.defs
* Library:          EE635Project
* Cell:             HALF_ADDER_OPT_VTC
* Testbench:        Spice
* View:             schematic2
* Export as:        top-level cell
* Export mode:      hierarchical
* Exclude empty:    yes
* Exclude .model:   no
* Exclude .hdl:     no
* Exclude .end:     no
* Expand paths:     yes
* Wrap lines:       no
* Exclude simulator commands:  no
* Exclude global pins:         no
* Exclude instance locations:  no
* Control property name(s):    SPICE

********* Simulation Settings - General Section *********
.lib "E:\6th Semester\EE635 Digital IC Design Nandekumar Sir\TannerTools_v2019.2\Process\Generic_250nm\Models\Generic_250nm.lib" TT

*************** Subcircuits *****************
.subckt TG_XOR A B Gnd Vdd Y 
MMn1 N_1 A Gnd Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=8600 $y=20900 $w=400 $h=600
MMn2 Y B N_1 Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=10000 $y=20900 $w=400 $h=600
MMn3 Y N_1 B Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=11700 $y=21000 $w=600 $h=400 $r=270
MMp1 N_1 A Vdd Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=8600 $y=22400 $w=400 $h=600
MMp2 Y B A Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=10000 $y=22400 $w=400 $h=600
MMp3 Y A B Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=11700 $y=22500 $w=600 $h=400 $r=90
.ends

.subckt INVERTER Gnd Vdd Vin Vout 
MMn1 Vout Vin Gnd Gnd NMOS25 w=1.5u l=250n m=1 ad=975f pd=4.3u as=975f ps=4.3u nrd=433.33333m nrs=433.33333m $ $x=4700 $y=4800 $w=400 $h=600
MMp1 Vout Vin Vdd Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=4700 $y=5600 $w=400 $h=600
.ends

.subckt NAND A B Gnd NAND_OUT Vdd 
MMn1 NAND_OUT A N_1 Gnd NMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=4600 $y=3700 $w=400 $h=600
MMn2 N_1 B Gnd Gnd NMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=4600 $y=2700 $w=400 $h=600
MMp1 NAND_OUT A Vdd Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=3700 $y=4900 $w=400 $h=600
MMp2 NAND_OUT B Vdd Vdd PMOS25 w=3u l=250n m=1 ad=1.95p pd=7.3u as=1.95p ps=7.3u nrd=216.66667m nrs=216.66667m $ $x=5600 $y=4900 $w=400 $h=600
.ends

.subckt AND2 A AND_OUT B Gnd Vdd 
XINVERTER_1 Gnd Vdd N_1 AND_OUT INVERTER $ $x=6700 $y=3900 $w=1800 $h=1800
XNAND_1 A B Gnd N_1 Vdd NAND $ $x=3900 $y=3900 $w=1800 $h=1800
.ends

.subckt HALF_ADDER_OPT A B COUT Gnd SUM Vdd 
XAND2_1 A COUT B Gnd Vdd AND2 $ $x=13900 $y=22100 $w=1800 $h=1800
XTG_XOR_1 A B Gnd Vdd SUM TG_XOR $ $x=11800 $y=22100 $w=1800 $h=1800
XTG_XOR_2 A B Gnd Vdd SUM TG_XOR $ $x=11800 $y=22100 $w=1800 $h=1800
.ends


***** Top Level *****
XHALF_ADDER_OPT_1 A B COUT Gnd SUM Vdd HALF_ADDER_OPT $ $x=13700 $y=18300 $w=1800 $h=1800

********* Simulation Settings - Analysis Section *********
Vdd Vdd 0 DC 2.5
Vgnd Gnd 0 DC 0 

* --- 2. Input Stimulus (Binary Counter Pattern) ---
Va A 0 PULSE(0 2.5 2n 100p 100p 2n 4n)
Vb B 0 PULSE(0 2.5 2n 100p 100p 4n 8n)

* --- 3. Analysis ---
.tran 10p 12n

* --- 4. Probing ---
.print tran v(A) v(B) v(SUM) v(COUT)
.print tran I(Vdd)

* --- 5. Power Measurements ---
* Total Average Power 
.measure tran I_avg_ha AVG I(Vdd) FROM=0n TO=12n
.measure tran P_avg_ha param='abs(I_avg_ha) * 2.5'

* Static/Leakage Power 
.measure tran I_stat_ha AVG I(Vdd) FROM=0.1n TO=1.9n
.measure tran P_stat_ha param='abs(I_stat_ha) * 2.5'

* Peak Switching Power 
.measure tran I_stress_ha AVG I(Vdd) FROM=9.9n TO=10.5n
.measure tran P_stress_ha param='abs(I_stress_ha) * 2.5'

.option gmin=1e-12 abstol=1e-9 reltol=0.01 threads=8
.end
********* Simulation Settings - Additional SPICE Commands *********

.end

